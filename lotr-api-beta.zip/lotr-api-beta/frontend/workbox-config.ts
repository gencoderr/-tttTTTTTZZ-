export default {
  globDirectory: 'build/',
  globPatterns: [
    '**/*.{json,ico,png,html,js,txt,css}'
  ],
  swDest: 'build/sw.js'
};
